package com.example.moviesreamingapp.data.models

import androidx.lifecycle.LiveData
import com.example.moviesreamingapp.data.models.Movie

data class AllMovies(

    val page: Int,
    val results : List<Movie>
){

}
