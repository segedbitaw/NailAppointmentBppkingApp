package com.example.moviesreamingapp.ui.PopularMovies

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.os.bundleOf
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.moviesreamingapp.ui.PopularMovies.PopularMoviesViewModel
import com.example.moviesreamingapp.R
import com.example.moviesreamingapp.databinding.FragmentPopularMoviesScreenBinding
import com.example.moviesreamingapp.utils.Error
import com.example.moviesreamingapp.utils.Loading
import com.example.moviesreamingapp.utils.Success
import dagger.hilt.android.AndroidEntryPoint


@AndroidEntryPoint
class PopularMoviesScreen : Fragment(),MoviesAdapter.MovieItemListener {

    private val viewModel : PopularMoviesViewModel by viewModels()

    private var _binding : FragmentPopularMoviesScreenBinding? = null

    private val binding get() = _binding!!

    private lateinit var adapter: MoviesAdapter


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        _binding = FragmentPopularMoviesScreenBinding.inflate(inflater,container,false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        adapter=MoviesAdapter(this)
        binding.movieRV.layoutManager = GridLayoutManager(requireContext(),2)
        binding.movieRV.adapter = adapter

        viewModel.moviesPopular.observe(viewLifecycleOwner){
            when(it.status) {

                is Success -> {
                    adapter.setMovies(ArrayList(it.status.data))
                    binding.progressBar.visibility = View.GONE
                }

                is Loading -> {
                    //Toast.makeText(requireContext(),"LOADING MOVIES",Toast.LENGTH_SHORT).show()
                    binding.progressBar.visibility = View.VISIBLE
                }

                is Error -> {
                    binding.progressBar.visibility = View.GONE
                    Toast.makeText(requireContext(),it.status.message,Toast.LENGTH_SHORT).show()
                }
            }
        }
//
        binding.toolbar.btnwatc.setOnClickListener(){
            findNavController().navigate(R.id.action_popularMoviesScreen_to_favoritesMoviesScreen)
        }
        binding.toolbar.btnSearch.setOnClickListener(){
            findNavController().navigate(R.id.action_popularMoviesScreen_to_searchMovieScreen)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    override fun onMovieClick(movieId: Int) {
            findNavController().navigate(R.id.action_popularMoviesScreen_to_singleMovieDetails,
                bundleOf("id" to movieId)
            )
    }

}