package com.example.moviesreamingapp.local_db

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.OnConflictStrategy
import com.example.moviesreamingapp.data.models.Movie


@Dao
interface MovieDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMovieList(movieList: List<Movie>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMovie(movie: Movie)

    @Query("SELECT * FROM movies WHERE id = :movieId")
     fun getMovieById(movieId: Int): LiveData<Movie?>

    @Query("SELECT * FROM movies WHERE title LIKE '%' || :keyword || '%'")
    fun getMovieSearch(keyword: String): LiveData<List<Movie>>


     @Query("SELECT * FROM movies")
    fun getAllPopularMovie() : LiveData<List<Movie>>

    @Query("SELECT * FROM movies WHERE isFavorite = 1")
    fun getFavorites(): LiveData<List<Movie>>

    @Query("UPDATE movies SET isFavorite = :isFavorite WHERE id = :movieId")
    suspend fun updateFavoriteStatus(movieId: Int, isFavorite: Boolean)


    @Delete
    suspend fun deleteMovie(vararg  items:Movie)

}