package com.example.moviesreamingapp.repositories

import android.util.Log
import android.widget.Toast
import androidx.core.content.ContentProviderCompat.requireContext
import androidx.lifecycle.LiveData
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.moviesreamingapp.data.models.AllVideos
import com.example.moviesreamingapp.data.models.Movie
import com.example.moviesreamingapp.data.models.Video
import com.example.moviesreamingapp.local_db.MovieDao
import com.example.moviesreamingapp.remote_db.MovieRemoteDataSource
import com.example.moviesreamingapp.utils.Resource
import com.example.moviesreamingapp.utils.preformFetchingAndSaving
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class MovieRepository @Inject constructor(private val remoteDataSource : MovieRemoteDataSource, private val localDataSource : MovieDao) {

    fun getPopularMovies() = preformFetchingAndSaving(
        {localDataSource.getAllPopularMovie()},
        {remoteDataSource.getPopularMovies()},
        {localDataSource.insertMovieList(it.results)}
    )

    fun getMovieById(id : Int) = preformFetchingAndSaving(
        {localDataSource.getMovieById(id)},
        {remoteDataSource.getMovieById(id)},
        {
            val localMovie = localDataSource.getMovieById(id)
            val remoteM = remoteDataSource.getMovieById(id)
            remoteM.status.data?.isFavorite ?: localMovie.value?.isFavorite ?:
            localDataSource.insertMovie(it)
        }
    )

    fun  getMovieSearch(keyword:String) = preformFetchingAndSaving(
        {localDataSource.getMovieSearch(keyword)},
        {remoteDataSource.searchMovie(keyword)},
        {localDataSource.insertMovieList(it.results)}
    )

    suspend fun getMovieTrailer(id: Int): Video? {
        val response = remoteDataSource.getMovieTrailer(id)
         if (response.status.data?.result?.isEmpty() == false) {
           return response.status.data.result.first()
        }
         else {
            return null
        }
    }

//    suspend fun getMovieVideos(id:Int): Resource<AllVideos> {
//       val response = remoteDataSource.getVideos(id)
//        return response
//       // return response.status.data?.results
//    }

    suspend fun updateFavoriteStatus(movieId: Int, isFavorite: Boolean) {
        localDataSource.updateFavoriteStatus(movieId, isFavorite)
    }

    fun getFavorites(): LiveData<List<Movie>> {
        return localDataSource.getFavorites()
    }

}