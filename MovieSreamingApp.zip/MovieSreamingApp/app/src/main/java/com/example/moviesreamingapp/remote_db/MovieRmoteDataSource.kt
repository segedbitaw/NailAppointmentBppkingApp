package com.example.moviesreamingapp.remote_db
import retrofit2.Response
import javax.inject.Inject
import javax.inject.Singleton


@Singleton
class MovieRemoteDataSource @Inject constructor(
    private val movieApi: MovieApi
) : BaseDataSource()
{
        suspend fun getPopularMovies() = gerResulte { movieApi.getPopularMoviesList() }
        suspend fun getMovieById(id: Int) = gerResulte { movieApi.getMovieById(id) }
        suspend fun searchMovie(query:String) = gerResulte { movieApi.searchMovie(query) }
        suspend fun getMovieTrailer(id:Int) = gerResulte { movieApi.getMovieTrailer(id) }

}