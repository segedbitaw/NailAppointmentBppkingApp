package com.example.moviesreamingapp.ui.PopularMovies

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.RecyclerView.LayoutManager
import com.bumptech.glide.Glide
import com.example.moviesreamingapp.data.models.Movie
import com.example.moviesreamingapp.databinding.MovieListItemBinding
import com.example.moviesreamingapp.utils.Constant

class MoviesAdapter (private val callBack: MovieItemListener)
: RecyclerView.Adapter<MoviesAdapter.MovieViewHolder>() {

    private val movies = ArrayList<Movie>()

    class MovieViewHolder (private val itemBinding: MovieListItemBinding,
                           private val callBack: MovieItemListener)
        : RecyclerView.ViewHolder(itemBinding.root),
        View.OnClickListener {
            private lateinit var movie: Movie

            init {
                itemBinding.root.setOnClickListener(this)
            }

        fun bind(item: Movie){
            this.movie = item
            itemBinding.tvTitle.text = item.title
            itemBinding.tvReleaseDate.text = item.release_date
            val fullPosterUrl = Constant.IMAGE_BASE_URL + item.poster_path
            Glide.with(itemBinding.root).load(fullPosterUrl).into(itemBinding.posterIv)
        }

        override fun onClick(v: View?) {
           callBack.onMovieClick(movie.id!!)
        }

    }

    interface MovieItemListener {
        fun onMovieClick(movieId:Int)
    }

    fun setMovies(movies: Collection<Movie>){
        this.movies.clear()
        this.movies.addAll(movies)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): MovieViewHolder {
        val binding = MovieListItemBinding.inflate(LayoutInflater.from(parent.context),parent,false)
        return MovieViewHolder(binding,callBack)
    }


    override fun onBindViewHolder(holder: MovieViewHolder, position: Int) {
        holder.bind(movies[position])
    }

    override fun getItemCount(): Int {
         return movies.size
    }
}