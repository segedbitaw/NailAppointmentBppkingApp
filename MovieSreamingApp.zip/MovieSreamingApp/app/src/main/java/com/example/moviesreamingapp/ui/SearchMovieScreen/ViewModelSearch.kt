package com.example.moviesreamingapp.ui.SearchMovieScreen

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.switchMap
import com.example.moviesreamingapp.data.models.Movie
import com.example.moviesreamingapp.repositories.MovieRepository
import com.example.moviesreamingapp.utils.Resource
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject


@HiltViewModel
class ViewModelSearch @Inject constructor(private val movieRepository: MovieRepository) : ViewModel() {


//    private val _movies = MutableLiveData<List<Movie>>() // Holds the movie list
//    val movies: LiveData<List<Movie>> get() = _movies  // Expose LiveData to UI
//
//     //Holds the movie list
//    fun searchMovies(query: String) {
//        viewModelScope.launch {
//            movieRepository.getMovieSearch(query).observeForever { resource ->
//                resource.status.data?.let { movie ->
//                    _movies.postValue(listOf(movie)) // Convert single Movie? to List<Movie>
//                } ?: _movies.postValue(emptyList()) // Handle null case
//            }
//        }
//    }


    private val _query = MutableLiveData<String>()

    val movies: LiveData<Resource<List<Movie>>> = _query.switchMap { query ->
        movieRepository.getMovieSearch(query)
    }

    fun setQuery(query: String) {
        _query.postValue(query) // or _query.postValue(query) if updating from a background thread
    }

}