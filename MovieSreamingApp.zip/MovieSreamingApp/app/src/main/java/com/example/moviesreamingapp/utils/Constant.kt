package com.example.moviesreamingapp.utils

class Constant {
    companion object{
        const val BASE_URL = "https://api.themoviedb.org/3/"
        const val API_KEY = "2eed05f5e3fb3deb2944039ecb7f78a1"
        const val IMAGE_BASE_URL = "https://image.tmdb.org/t/p/w500/"
    }
}