package com.example.moviesreamingapp.ui.SingleMovieScreen

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.liveData
import androidx.lifecycle.switchMap
import androidx.lifecycle.viewModelScope
import com.example.moviesreamingapp.data.models.AllVideos
import com.example.moviesreamingapp.data.models.Movie
import com.example.moviesreamingapp.data.models.Video
import com.example.moviesreamingapp.repositories.MovieRepository
import com.example.moviesreamingapp.utils.Resource
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject


@HiltViewModel
class MovieDetailsViewModel @Inject constructor( private val movieRepository: MovieRepository) : ViewModel() {

    private val _id = MutableLiveData<Int>()

    private val _movie =_id.switchMap {
        movieRepository.getMovieById(it)
    }
    val movie: LiveData<Resource<Movie?>> = _movie

    fun setId(id: Int){
        _id.value = id

    }
    fun updateFavoriteStatus(movieId: Int, isFavorite: Boolean) {
        viewModelScope.launch {
            movieRepository.updateFavoriteStatus(movieId, isFavorite)
        }
    }

    private val _movieVideo = MutableLiveData<Video?>()
    val movieVideo: LiveData<Video?> = _movieVideo

    fun fetchMovieTrailer(movieId: Int) {
        viewModelScope.launch {
            val videoKey = movieRepository.getMovieTrailer(movieId)
            _movieVideo.postValue(videoKey) // Update LiveData for UI
        }
    }
}