package com.example.moviesreamingapp.ui.SingleMovieScreen

import android.annotation.SuppressLint
import android.content.Context
import android.location.Geocoder
import android.location.Location
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.GridLayoutManager
import com.bumptech.glide.Glide
import com.example.moviesreamingapp.R
import com.example.moviesreamingapp.data.models.Movie
import com.example.moviesreamingapp.databinding.FragmentSingleMovieDetailsBinding
import com.example.moviesreamingapp.ui.PopularMovies.MoviesAdapter
import com.example.moviesreamingapp.utils.Constant
import com.example.moviesreamingapp.utils.Error
import com.example.moviesreamingapp.utils.Loading
import com.example.moviesreamingapp.utils.Success
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.YouTubePlayer
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.listeners.AbstractYouTubePlayerListener
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.listeners.YouTubePlayerCallback
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.views.YouTubePlayerView
import dagger.hilt.android.AndroidEntryPoint
import java.util.Locale


@AndroidEntryPoint
class SingleMovieDetails : Fragment()  {

    private val viewModel: MovieDetailsViewModel by viewModels()

    private var _binding : FragmentSingleMovieDetailsBinding? = null

    private val binding get() = _binding!!

    //private lateinit var youTubePlayerView: YouTubePlayerView

    private var isFavorite: Boolean = false  // Track favorite status
    private var movieId: Int? = null         // Store movie ID


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        _binding = FragmentSingleMovieDetailsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)


        arguments?.getInt("id")?.let{
            movieId = it
            viewModel.setId(it)
        }

        viewModel.movie.observe(viewLifecycleOwner){
            when(it.status) {

                is Success -> {
                    updateMovie(it.status.data!!)
                }

                is Loading -> {}
                is Error -> {Toast.makeText(requireContext(),it.status.message,Toast.LENGTH_SHORT).show()}
            }
        }

//        viewModel.movieVideo.observe(viewLifecycleOwner) { video ->
//            if (video != null) {
//                playYouTubeVideo(video.key)
//            } else {
//                Toast.makeText(requireContext(), "No Trailer Available", Toast.LENGTH_SHORT).show()
//            }
//        }

        binding.IvIcon.setOnClickListener(){
            movieId?.let { id ->
                isFavorite = !isFavorite // Toggle favorite state
                viewModel.updateFavoriteStatus(id, isFavorite) // Update database
                updateFavoriteIcon() // Change icon
            }
        }




    }


    fun updateMovie(movie: Movie){
        binding.itemTitle.text = "Title : ${movie.title}"
        binding.movieDesc.text = "overview : ${movie.overview}"
        binding.movieYear.text = "released : ${movie.release_date}"
        binding.tvLanguage.text = "language : ${movie.original_language}"
        Glide.with(requireContext()).load((Constant.IMAGE_BASE_URL + movie.poster_path)).into(binding.itemImage)
        isFavorite = movie.isFavorite
        updateFavoriteIcon()
    }

//    private fun playYouTubeVideo(videoKey: String) {
//        binding.youtubePlayerView.addYouTubePlayerListener(object : AbstractYouTubePlayerListener() {
//            override fun onReady(youTubePlayer: YouTubePlayer) {
//                youTubePlayer.loadVideo(videoKey, 0f)
//            youTubePlayer.play()// Load video at 0 seconds
//            }
//        })
//    }
    @SuppressLint("MissingPermission")
    fun getCountryFromLocation(context: Context, location: Location): String {
        val geocoder = Geocoder(context, Locale.getDefault())
        val addresses = geocoder.getFromLocation(location.latitude, location.longitude, 1)
        return addresses?.firstOrNull()?.countryCode ?: Locale.getDefault().country
    }

    private fun updateFavoriteIcon() {
        binding.IvIcon.setImageResource(
            if (isFavorite) R.drawable.ic_bookmark2
            else R.drawable.ic_bookmark
        )
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

}