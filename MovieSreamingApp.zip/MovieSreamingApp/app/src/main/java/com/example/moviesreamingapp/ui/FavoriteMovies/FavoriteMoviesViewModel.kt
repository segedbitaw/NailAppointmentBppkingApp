package com.example.moviesreamingapp.ui.FavoriteMovies

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.moviesreamingapp.data.models.Movie
import com.example.moviesreamingapp.repositories.MovieRepository
import com.example.moviesreamingapp.utils.Resource
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject


@HiltViewModel
class FavoriteMoviesViewModel @Inject constructor(private val movieRepository: MovieRepository) : ViewModel() {

    val movies = movieRepository.getFavorites()

    fun getMovieById(id : Int) = movieRepository.getMovieById(id)
}