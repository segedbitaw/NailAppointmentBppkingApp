package com.example.moviesreamingapp.data.models



data class Video (
    val id:Int,
    // needed for playing video on youtube
    val key: String,

    val site: String,
    val type: String
)