package com.example.finalkotlinandroidapp.di

import android.app.Application
import android.content.Context
import com.example.moviesreamingapp.local_db.AppDataBase
import com.example.moviesreamingapp.local_db.MovieDao
import com.example.moviesreamingapp.remote_db.MovieApi
import com.example.moviesreamingapp.utils.Constant
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
 object AppModule {

     @Singleton
     @Provides
     fun providesRetrofit(gson: Gson): Retrofit{
         return  Retrofit.Builder().baseUrl(Constant.BASE_URL)
             .addConverterFactory(GsonConverterFactory.create(gson)).build()
     }

    @Provides
    fun providesGson() : Gson = GsonBuilder().create()

    @Provides
    @Singleton
    fun providesMovieDatabase(@ApplicationContext appContext:Context) : AppDataBase{
       return AppDataBase.getDatabase(appContext)
    }

    @Provides
    fun provideMovieDao(database: AppDataBase): MovieDao {
        return database.movieDao()
    }

    @Provides
    @Singleton
    fun provideMovieApiService(retrofit: Retrofit) : MovieApi{
        return retrofit.create(MovieApi::class.java)
    }

}