package com.example.moviesreamingapp.ui.PopularMovies


import androidx.lifecycle.ViewModel
import com.example.moviesreamingapp.repositories.MovieRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject


@HiltViewModel
class PopularMoviesViewModel @Inject constructor(movieRepository: MovieRepository) : ViewModel() {

    val moviesPopular = movieRepository.getPopularMovies()

}