package com.example.moviesreamingapp.remote_db

import com.example.moviesreamingapp.data.models.AllMovies
import com.example.moviesreamingapp.data.models.AllVideos
import com.example.moviesreamingapp.data.models.Movie
import com.example.moviesreamingapp.utils.Constant.Companion.API_KEY
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query


//////////MovieService////////////
interface MovieApi {
    @GET("movie/now_playing")
    suspend fun getPopularMoviesList(
        @Query("language") language: String = "en-US",
        @Query("page") page : Int = 1,
        @Query("api_key") apiKey : String = API_KEY
    ) : Response<AllMovies>


    //search by movie id(550)
    //https://api.themoviedb.org/3/movie/550?api_key={api_key}
    @GET("movie/{id}")
    suspend fun getMovieById(
        @Path("id") id : Int,
        @Query("api_key") apiKey : String = API_KEY
    ): Response<Movie>


    // search for movie by keyword
    //https://api.themoviedb.org/3/searc/movie?api_key={api_key}&query=Jack+Reacher

    @GET("search/movie")
    suspend fun searchMovie(
        @Query("query") query: String,
        @Query("page") page : Int = 1,
        @Query("api_key") apiKey : String = API_KEY
    ): Response<AllMovies>


    @GET("movie/{id}/videos")
    suspend fun getMovieTrailer(
        @Path("id") id: Int,
        @Query("api_key") apiKey: String = API_KEY
    ): Response<AllVideos>

}