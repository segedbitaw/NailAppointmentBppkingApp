package com.example.moviesreamingapp.ui.SearchMovieScreen

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.SearchView
import android.widget.Toast
import androidx.core.os.bundleOf
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.moviesreamingapp.R
import com.example.moviesreamingapp.databinding.FragmentSearchMovieScreenBinding
import com.example.moviesreamingapp.ui.PopularMovies.MoviesAdapter
import com.example.moviesreamingapp.utils.Error
import com.example.moviesreamingapp.utils.Loading
import com.example.moviesreamingapp.utils.Success
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class SearchMovieScreen : Fragment(), MoviesAdapter.MovieItemListener {

    private var _binding: FragmentSearchMovieScreenBinding? = null
    private val binding get() = _binding!!
    private val viewModel: ViewModelSearch by viewModels()
    private lateinit var adapter: MoviesAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSearchMovieScreenBinding.inflate(inflater, container, false)

        adapter = MoviesAdapter(this)
        binding.rvSearch.layoutManager = LinearLayoutManager(context)
        binding.rvSearch.adapter = adapter

        viewModel.movies.observe(viewLifecycleOwner) {
            when(it.status) {

                is Success -> {
                    ArrayList(it.status.data).let { it1 -> adapter.setMovies(it1) }
                    //binding.progressBar.visibility = View.GONE
                }

                is Loading -> {
                    Toast.makeText(requireContext(),"LOADING MOVIES",Toast.LENGTH_SHORT).show()
                    //binding.progressBar.visibility = View.VISIBLE
                }

                is Error -> {
                    //binding.progressBar.visibility = View.GONE
                    Toast.makeText(requireContext(),it.status.message, Toast.LENGTH_SHORT).show()
                }
            }
    //                movieList ->
    //            movieList?.let { adapter.setMovies(it) } // Update adapter with new movie list
        }

        binding.SearchBAr.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                query?.let {
                    viewModel.setQuery(it) // Fetch movies based on query
                }
                return true
            }
            override fun onQueryTextChange(newText: String?): Boolean {
                return false
            }
        })

        return binding.root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    override fun onMovieClick(movieId: Int) {
        // ✅ Navigate to Single Movie Details instead of Search Screen
        findNavController().navigate(
            R.id.action_searchMovieScreen_to_singleMovieDetails,
            bundleOf("id" to movieId)
        )
    }
}