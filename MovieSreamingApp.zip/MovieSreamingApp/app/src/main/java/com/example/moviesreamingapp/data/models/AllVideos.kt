package com.example.moviesreamingapp.data.models

data class AllVideos (val id:Int,val result:List<Video>){
}